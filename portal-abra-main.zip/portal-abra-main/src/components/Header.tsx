import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { PlusCircle, List, Home } from "lucide-react";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-gradient-to-r from-primary/10 via-background to-secondary/10 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold text-primary">CadEspecial</span>
          </Link>
        </div>
        <nav className="flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link to="/" className="flex items-center gap-1">
              <Home className="h-4 w-4" />
              Início
            </Link>
          </Button>
          <Button asChild variant="ghost" size="sm">
            <Link to="/cadastro" className="flex items-center gap-1">
              <PlusCircle className="h-4 w-4" />
              Novo Cadastro
            </Link>
          </Button>
          <Button asChild variant="ghost" size="sm">
            <Link to="/lista" className="flex items-center gap-1">
              <List className="h-4 w-4" />
              Listar Cadastros
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
}