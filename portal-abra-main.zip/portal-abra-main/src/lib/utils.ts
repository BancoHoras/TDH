import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Função para converter texto para maiúsculas
export function toUpperCase(text: string): string {
  return text.toUpperCase()
}

// Função para formatar data de DD/MM/YYYY para YYYY-MM-DD (formato de input HTML)
export function formatDateForInput(date: string): string {
  if (!date) return ""
  
  const parts = date.split('/')
  if (parts.length !== 3) return date
  
  return `${parts[2]}-${parts[1]}-${parts[0]}`
}

// Função para formatar data de YYYY-MM-DD para DD/MM/YYYY (formato de exibição)
export function formatDateForDisplay(date: string): string {
  if (!date) return ""
  
  const d = new Date(date)
  if (isNaN(d.getTime())) return date
  
  return d.toLocaleDateString('pt-BR')
}

// Função para criar um arquivo de exportação
export function exportToCSV(data: any[]): string {
  if (!data || !data.length) return ''
  
  // Obter cabeçalhos
  const headers = Object.keys(data[0])
  
  // Criar linha de cabeçalho
  const headerRow = headers.join(',')
  
  // Criar linhas de dados
  const rows = data.map(obj => 
    headers.map(header => {
      let cell = obj[header] === null || obj[header] === undefined ? '' : obj[header]
      // Se for string com vírgula, colocar entre aspas
      if (typeof cell === 'string' && cell.includes(',')) {
        return `"${cell}"`
      }
      return cell
    }).join(',')
  )
  
  // Combinar todas as linhas
  return [headerRow, ...rows].join('\n')
}

// Função para exportar para JSON
export function exportToJSON(data: any[]): string {
  return JSON.stringify(data, null, 2)
}

// Função para exportar para XML
export function exportToXML(data: any[]): string {
  let xml = '<?xml version="1.0" encoding="UTF-8" ?>\n<cadastros>\n'
  
  data.forEach((item) => {
    xml += '  <cadastro>\n'
    Object.entries(item).forEach(([key, value]) => {
      xml += `    <${key}>${value}</${key}>\n`
    })
    xml += '  </cadastro>\n'
  })
  
  xml += '</cadastros>'
  return xml
}

// Gerar um ID único
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2)
}