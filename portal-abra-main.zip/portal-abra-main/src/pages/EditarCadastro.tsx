import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { FormularioCadastro } from "@/components/FormularioCadastro";
import { useCadastro } from "@/context/CadastroContext";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

const EditarCadastro = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getCadastro, updateCadastro } = useCadastro();
  
  const cadastro = id ? getCadastro(id) : undefined;

  useEffect(() => {
    if (!cadastro && id) {
      // Se o cadastro não existir, redirecionar para a lista
      navigate("/lista");
    }
  }, [cadastro, id, navigate]);

  const handleSubmit = async (data: any) => {
    if (id) {
      await updateCadastro(id, data);
      navigate("/lista");
    }
  };

  if (!cadastro) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="container flex-1 py-10">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erro</AlertTitle>
            <AlertDescription>
              Cadastro não encontrado. Redirecionando...
            </AlertDescription>
          </Alert>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 py-10">
        <div className="mx-auto max-w-3xl">
          <FormularioCadastro
            initialData={cadastro}
            onSubmit={handleSubmit}
            isUpdate
          />
        </div>
      </main>
    </div>
  );
};

export default EditarCadastro;