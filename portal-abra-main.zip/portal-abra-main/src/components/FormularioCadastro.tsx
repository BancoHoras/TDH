import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { tiposDeficiencia, Cadastro } from "@/types";
import { CalendarDays, User, Pencil, Tag, Save } from "lucide-react";
import { toUpperCase } from "@/lib/utils";

// Schema para validação do formulário
const cadastroSchema = z.object({
  gmus: z.string().min(1, "G'MUS é obrigatório"),
  nome: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  dataNascimento: z.string().min(1, "Data de nascimento é obrigatória"),
  tipoDeficiencia: z.string().min(1, "Tipo de deficiência é obrigatório"),
  profissional: z.string().min(3, "Nome do profissional é obrigatório"),
  observacao: z.string().optional(),
});

type CadastroFormData = z.infer<typeof cadastroSchema>;

interface FormularioCadastroProps {
  initialData?: Partial<Cadastro>;
  onSubmit: (data: CadastroFormData) => void;
  isUpdate?: boolean;
}

export function FormularioCadastro({ initialData, onSubmit, isUpdate = false }: FormularioCadastroProps) {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<CadastroFormData>({
    resolver: zodResolver(cadastroSchema),
    defaultValues: {
      gmus: initialData?.gmus || "",
      nome: initialData?.nome || "",
      dataNascimento: initialData?.dataNascimento || "",
      tipoDeficiencia: initialData?.tipoDeficiencia || "",
      profissional: initialData?.profissional || "",
      observacao: initialData?.observacao || "",
    },
  });

  // Função para lidar com a seleção do tipo de deficiência
  const handleDeficienciaChange = (value: string) => {
    setValue("tipoDeficiencia", value);
  };

  // Handler para converter input para maiúsculas na UI
  const handleUpperCaseInput = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    e.target.value = toUpperCase(e.target.value);
  };

  return (
    <Card className="w-full max-w-3xl" variant="gradient">
      <CardHeader className="space-y-1 text-center">
        <CardTitle className="text-2xl font-bold">
          {isUpdate ? "Atualizar Cadastro" : "Cadastro de Criança Especial"}
        </CardTitle>
        <CardDescription>
          Preencha os dados abaixo para {isUpdate ? "atualizar o" : "realizar um novo"} cadastro
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit(onSubmit)}>
        <CardContent className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="gmus" className="flex items-center gap-1">
              <Tag className="h-4 w-4" />
              G'MUS
            </Label>
            <Input
              id="gmus"
              placeholder="Informe o G'MUS"
              {...register("gmus")}
              onChange={handleUpperCaseInput}
              className="bg-background/60"
            />
            {errors.gmus && (
              <p className="text-sm text-destructive">{errors.gmus.message}</p>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="nome" className="flex items-center gap-1">
              <User className="h-4 w-4" />
              Nome Completo
            </Label>
            <Input
              id="nome"
              placeholder="Nome da criança"
              {...register("nome")}
              onChange={handleUpperCaseInput}
              className="bg-background/60"
            />
            {errors.nome && (
              <p className="text-sm text-destructive">{errors.nome.message}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="dataNascimento" className="flex items-center gap-1">
                <CalendarDays className="h-4 w-4" />
                Data de Nascimento
              </Label>
              <Input
                id="dataNascimento"
                type="date"
                {...register("dataNascimento")}
                className="bg-background/60"
              />
              {errors.dataNascimento && (
                <p className="text-sm text-destructive">
                  {errors.dataNascimento.message}
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="tipoDeficiencia" className="flex items-center gap-1">
                Tipo de Deficiência
              </Label>
              <Select
                onValueChange={handleDeficienciaChange}
                defaultValue={initialData?.tipoDeficiencia}
              >
                <SelectTrigger id="tipoDeficiencia" className="bg-background/60">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  {tiposDeficiencia.map((tipo) => (
                    <SelectItem key={tipo} value={tipo}>
                      {tipo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.tipoDeficiencia && (
                <p className="text-sm text-destructive">
                  {errors.tipoDeficiencia.message}
                </p>
              )}
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="profissional" className="flex items-center gap-1">
              <Pencil className="h-4 w-4" />
              Profissional Responsável
            </Label>
            <Input
              id="profissional"
              placeholder="Nome do profissional"
              {...register("profissional")}
              onChange={handleUpperCaseInput}
              className="bg-background/60"
            />
            {errors.profissional && (
              <p className="text-sm text-destructive">
                {errors.profissional.message}
              </p>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="observacao">Observação</Label>
            <Textarea
              id="observacao"
              placeholder="Observações adicionais"
              {...register("observacao")}
              onChange={handleUpperCaseInput}
              className="min-h-[100px] bg-background/60"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={() => window.history.back()}
          >
            Cancelar
          </Button>
          <Button type="submit" disabled={isSubmitting} variant="gradient">
            <Save className="mr-2 h-4 w-4" />
            {isUpdate ? "Atualizar" : "Cadastrar"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}