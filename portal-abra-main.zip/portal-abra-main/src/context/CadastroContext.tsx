import React, { createContext, useState, useContext, useEffect } from "react";
import { Cadastro } from "@/types";
import { toUpperCase } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface CadastroContextType {
  cadastros: Cadastro[];
  loading: boolean;
  addCadastro: (cadastro: Omit<Cadastro, "id" | "dataCadastro">) => Promise<void>;
  updateCadastro: (id: string, cadastro: Partial<Cadastro>) => Promise<void>;
  deleteCadastro: (id: string) => Promise<void>;
  getCadastro: (id: string) => Cadastro | undefined;
  refreshCadastros: () => Promise<void>;
}

const CadastroContext = createContext<CadastroContextType | undefined>(undefined);

export const CadastroProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cadastros, setCadastros] = useState<Cadastro[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();

  // Função para carregar os cadastros do Supabase
  const fetchCadastros = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('cadastros')
        .select('*');

      if (error) {
        throw error;
      }

      // Converter os dados do formato do Supabase para o formato da aplicação
      const formattedData: Cadastro[] = data.map(item => ({
        id: item.id,
        gmus: item.gmus,
        nome: item.nome,
        dataNascimento: item.data_nascimento,
        tipoDeficiencia: item.tipo_deficiencia as Cadastro['tipoDeficiencia'],
        profissional: item.profissional,
        observacao: item.observacao || '',
        dataCadastro: item.data_cadastro
      }));

      setCadastros(formattedData);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar cadastros",
        description: error.message || "Não foi possível carregar os cadastros.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Carregar cadastros ao iniciar
  useEffect(() => {
    fetchCadastros();
  }, []);

  // Adicionar novo cadastro
  const addCadastro = async (cadastro: Omit<Cadastro, "id" | "dataCadastro">) => {
    try {
      // Converter todos os campos de texto para maiúsculas
      const processedData = {
        gmus: toUpperCase(cadastro.gmus),
        nome: toUpperCase(cadastro.nome),
        data_nascimento: cadastro.dataNascimento,
        tipo_deficiencia: cadastro.tipoDeficiencia,
        profissional: toUpperCase(cadastro.profissional),
        observacao: cadastro.observacao ? toUpperCase(cadastro.observacao) : null
      };

      const { data, error } = await supabase
        .from('cadastros')
        .insert(processedData)
        .select();

      if (error) {
        throw error;
      }

      // Atualizar o estado com o novo cadastro
      await fetchCadastros();

      toast({
        title: "Cadastro realizado",
        description: "O cadastro foi adicionado com sucesso.",
        variant: "default",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao adicionar cadastro",
        description: error.message || "Não foi possível adicionar o cadastro.",
        variant: "destructive",
      });
    }
  };

  // Atualizar cadastro existente
  const updateCadastro = async (id: string, cadastro: Partial<Cadastro>) => {
    try {
      // Processar campos de texto para maiúsculas
      const processedUpdate: any = {};
      
      if (cadastro.gmus) processedUpdate.gmus = toUpperCase(cadastro.gmus);
      if (cadastro.nome) processedUpdate.nome = toUpperCase(cadastro.nome);
      if (cadastro.dataNascimento) processedUpdate.data_nascimento = cadastro.dataNascimento;
      if (cadastro.tipoDeficiencia) processedUpdate.tipo_deficiencia = cadastro.tipoDeficiencia;
      if (cadastro.profissional) processedUpdate.profissional = toUpperCase(cadastro.profissional);
      if (cadastro.observacao !== undefined) {
        processedUpdate.observacao = cadastro.observacao ? toUpperCase(cadastro.observacao) : null;
      }

      const { error } = await supabase
        .from('cadastros')
        .update(processedUpdate)
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Atualizar o estado com os dados atualizados
      await fetchCadastros();
      
      toast({
        title: "Cadastro atualizado",
        description: "O cadastro foi atualizado com sucesso.",
        variant: "default",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar cadastro",
        description: error.message || "Não foi possível atualizar o cadastro.",
        variant: "destructive",
      });
    }
  };

  // Excluir cadastro
  const deleteCadastro = async (id: string) => {
    try {
      const { error } = await supabase
        .from('cadastros')
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      // Atualizar o estado removendo o cadastro
      setCadastros(prev => prev.filter(item => item.id !== id));
      
      toast({
        title: "Cadastro excluído",
        description: "O cadastro foi excluído com sucesso.",
        variant: "destructive",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao excluir cadastro",
        description: error.message || "Não foi possível excluir o cadastro.",
        variant: "destructive",
      });
    }
  };

  // Obter um cadastro específico por ID
  const getCadastro = (id: string) => {
    return cadastros.find((cadastro) => cadastro.id === id);
  };

  // Função para recarregar os cadastros
  const refreshCadastros = async () => {
    await fetchCadastros();
  };

  return (
    <CadastroContext.Provider
      value={{
        cadastros,
        loading,
        addCadastro,
        updateCadastro,
        deleteCadastro,
        getCadastro,
        refreshCadastros
      }}
    >
      {children}
    </CadastroContext.Provider>
  );
};

export const useCadastro = () => {
  const context = useContext(CadastroContext);
  if (context === undefined) {
    throw new Error("useCadastro deve ser usado dentro de um CadastroProvider");
  }
  return context;
};