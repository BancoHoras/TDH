import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, List, FileText } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 py-10">
        <div className="mx-auto max-w-6xl space-y-8">
          <div className="text-center space-y-3">
            <h1 className="text-4xl font-bold text-primary">Sistema de Cadastro de Crianças Especiais</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Gerenciamento simplificado para cadastros de crianças com necessidades especiais
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
            <Card variant="gradient">
              <CardHeader>
                <CardTitle>Novo Cadastro</CardTitle>
                <CardDescription>
                  Cadastre uma nova criança no sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Adicione informações como G'MUS, nome, data de nascimento, tipo de deficiência e detalhes profissionais.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full" variant="secondary">
                  <Link to="/cadastro" className="flex items-center justify-center gap-2">
                    <PlusCircle className="h-5 w-5" />
                    Novo Cadastro
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card variant="gradient">
              <CardHeader>
                <CardTitle>Listar Cadastros</CardTitle>
                <CardDescription>
                  Visualize e gerencie cadastros existentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Acesse a lista completa dos cadastros, com opções para visualizar, editar ou excluir registros.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full" variant="secondary">
                  <Link to="/lista" className="flex items-center justify-center gap-2">
                    <List className="h-5 w-5" />
                    Listar Cadastros
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card variant="gradient">
              <CardHeader>
                <CardTitle>Exportar Dados</CardTitle>
                <CardDescription>
                  Exporte os cadastros em diversos formatos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Exporte os dados dos cadastros em diferentes formatos como CSV, JSON ou XML para uso em outros sistemas.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full" variant="secondary">
                  <Link to="/lista" className="flex items-center justify-center gap-2">
                    <FileText className="h-5 w-5" />
                    Acessar Exportação
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground text-center md:text-left">
            &copy; {new Date().getFullYear()} Sistema de Cadastro de Crianças Especiais. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;