import React, { useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { useCadastro } from "@/context/CadastroContext";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardFooter, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, Calendar, Edit, ArrowLeft, Trash2 } from "lucide-react";
import { formatDateForDisplay } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const VisualizarCadastro = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getCadastro, deleteCadastro } = useCadastro();

  const cadastro = id ? getCadastro(id) : undefined;

  useEffect(() => {
    if (!cadastro && id) {
      // Se o cadastro não existir, redirecionar para a lista
      navigate("/lista");
    }
  }, [cadastro, id, navigate]);

  const handleDelete = async () => {
    if (id) {
      await deleteCadastro(id);
      navigate("/lista");
    }
  };

  if (!cadastro) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="container flex-1 py-10">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erro</AlertTitle>
            <AlertDescription>
              Cadastro não encontrado. Redirecionando...
            </AlertDescription>
          </Alert>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 py-10">
        <div className="mx-auto max-w-3xl">
          <Card variant="gradient">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl">{cadastro.nome}</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    G'MUS: {cadastro.gmus}
                  </p>
                </div>
                <Button asChild variant="outline" size="sm">
                  <Link to="/lista">
                    <ArrowLeft className="mr-1 h-4 w-4" />
                    Voltar
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <h3 className="text-sm font-medium text-muted-foreground">Data de Nascimento</h3>
                  <p className="flex items-center gap-2 font-medium">
                    <Calendar className="h-4 w-4 text-primary" />
                    {formatDateForDisplay(cadastro.dataNascimento)}
                  </p>
                </div>
                <div className="space-y-1">
                  <h3 className="text-sm font-medium text-muted-foreground">Tipo de Deficiência</h3>
                  <p className="font-medium">{cadastro.tipoDeficiencia}</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-1">
                <h3 className="text-sm font-medium text-muted-foreground">Profissional Responsável</h3>
                <p className="font-medium">{cadastro.profissional}</p>
              </div>

              <div className="space-y-1">
                <h3 className="text-sm font-medium text-muted-foreground">Observações</h3>
                <div className="bg-background/60 rounded-md p-3 min-h-[100px]">
                  {cadastro.observacao ? (
                    <p>{cadastro.observacao}</p>
                  ) : (
                    <p className="text-muted-foreground italic">Nenhuma observação registrada</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <h3 className="text-sm font-medium text-muted-foreground">Data de Cadastro</h3>
                  <p className="text-sm">
                    {new Date(cadastro.dataCadastro).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button asChild variant="outline">
                <Link to={`/editar/${cadastro.id}`}>
                  <Edit className="mr-1 h-4 w-4" />
                  Editar
                </Link>
              </Button>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="mr-1 h-4 w-4" />
                    Excluir
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmação</AlertDialogTitle>
                    <AlertDialogDescription>
                      Tem certeza que deseja excluir este cadastro? Esta ação não pode ser desfeita.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-destructive text-destructive-foreground"
                      onClick={handleDelete}
                    >
                      Excluir
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default VisualizarCadastro;