import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CadastroProvider } from "@/context/CadastroContext";

// Páginas
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import NovoCadastro from "./pages/NovoCadastro";
import ListaCadastros from "./pages/ListaCadastros";
import EditarCadastro from "./pages/EditarCadastro";
import VisualizarCadastro from "./pages/VisualizarCadastro";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <CadastroProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/cadastro" element={<NovoCadastro />} />
            <Route path="/lista" element={<ListaCadastros />} />
            <Route path="/editar/:id" element={<EditarCadastro />} />
            <Route path="/visualizar/:id" element={<VisualizarCadastro />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </CadastroProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
