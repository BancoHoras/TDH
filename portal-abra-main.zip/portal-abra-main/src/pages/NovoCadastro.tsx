import React from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { FormularioCadastro } from "@/components/FormularioCadastro";
import { useCadastro } from "@/context/CadastroContext";

const NovoCadastro = () => {
  const navigate = useNavigate();
  const { addCadastro } = useCadastro();

  const handleSubmit = async (data: any) => {
    await addCadastro(data);
    navigate("/lista");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 py-10">
        <div className="mx-auto max-w-3xl">
          <FormularioCadastro onSubmit={handleSubmit} />
        </div>
      </main>
    </div>
  );
};

export default NovoCadastro;