import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pencil, Trash2, Eye, Download, Search, FileText, Plus } from "lucide-react";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger 
} from "@/components/ui/alert-dialog";
import { Cadastro } from "@/types";
import { formatDateForDisplay } from "@/lib/utils";
import { ExportMenu } from "@/components/ExportMenu";

interface TabelaCadastrosProps {
  cadastros: Cadastro[];
  onDelete: (id: string) => void;
  loading?: boolean;
}

export function TabelaCadastros({ cadastros, onDelete, loading = false }: TabelaCadastrosProps) {
  const [searchTerm, setSearchTerm] = useState("");

  // Filtrar cadastros com base no termo de pesquisa
  const filteredCadastros = cadastros.filter((cadastro) =>
    cadastro.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cadastro.gmus.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cadastro.tipoDeficiencia.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="w-full" variant="elevated">
      <CardHeader className="pb-2">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
          <CardTitle>Lista de Cadastros</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar cadastros..."
                className="w-full sm:w-[250px] pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <ExportMenu data={filteredCadastros} />
              <Button asChild variant="gradient" size="sm">
                <Link to="/cadastro">
                  <Plus className="mr-1 h-4 w-4" />
                  Novo
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative w-full overflow-auto rounded-md border">
          <table className="w-full caption-bottom">
            <thead className="border-b bg-muted/50">
              <tr>
                <th className="h-10 px-2 text-left align-middle font-medium text-muted-foreground">G'MUS</th>
                <th className="h-10 px-2 text-left align-middle font-medium text-muted-foreground">Nome</th>
                <th className="h-10 px-2 text-left align-middle font-medium text-muted-foreground">Data Nasc.</th>
                <th className="h-10 px-2 text-left align-middle font-medium text-muted-foreground">Tipo</th>
                <th className="h-10 px-2 text-left align-middle font-medium text-muted-foreground">Profissional</th>
                <th className="h-10 px-2 text-center align-middle font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-4 text-center text-muted-foreground">
                    <div className="flex items-center justify-center">
                      <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                      <span className="ml-2">Carregando cadastros...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredCadastros.length > 0 ? (
                filteredCadastros.map((cadastro) => (
                  <tr key={cadastro.id} className="border-b hover:bg-muted/50 transition-colors">
                    <td className="p-2 align-middle">{cadastro.gmus}</td>
                    <td className="p-2 align-middle">{cadastro.nome}</td>
                    <td className="p-2 align-middle">{formatDateForDisplay(cadastro.dataNascimento)}</td>
                    <td className="p-2 align-middle">{cadastro.tipoDeficiencia}</td>
                    <td className="p-2 align-middle">{cadastro.profissional}</td>
                    <td className="p-2 align-middle">
                      <div className="flex justify-center gap-1">
                        <Button asChild variant="ghost" size="icon-sm">
                          <Link to={`/visualizar/${cadastro.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button asChild variant="ghost" size="icon-sm">
                          <Link to={`/editar/${cadastro.id}`}>
                            <Pencil className="h-4 w-4" />
                          </Link>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon-sm">
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmação</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tem certeza que deseja excluir este cadastro? Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction 
                                className="bg-destructive text-destructive-foreground"
                                onClick={() => onDelete(cadastro.id)}
                              >
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="p-4 text-center text-muted-foreground">
                    {searchTerm ? (
                      <>
                        <FileText className="mx-auto h-6 w-6 mb-2 opacity-50" />
                        Nenhum cadastro encontrado para "{searchTerm}"
                      </>
                    ) : (
                      <>
                        <FileText className="mx-auto h-6 w-6 mb-2 opacity-50" />
                        Nenhum cadastro registrado ainda
                      </>
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}