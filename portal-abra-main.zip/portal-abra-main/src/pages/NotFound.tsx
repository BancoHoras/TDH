import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Header } from "@/components/Header";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 flex items-center justify-center">
        <div className="text-center space-y-6">
          <h1 className="text-8xl font-bold text-primary">404</h1>
          <p className="text-2xl text-muted-foreground mb-6">Página não encontrada</p>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">
            A página que você está procurando não existe ou foi movida.
          </p>
          <Button asChild variant="gradient" size="lg">
            <Link to="/" className="flex items-center gap-2">
              <Home className="h-5 w-5" />
              Voltar para a Página Inicial
            </Link>
          </Button>
        </div>
      </main>
    </div>
  );
};

export default NotFound;
