import React from "react";
import { Header } from "@/components/Header";
import { TabelaCadastros } from "@/components/TabelaCadastros";
import { useCadastro } from "@/context/CadastroContext";

const ListaCadastros = () => {
  const { cadastros, deleteCadastro, loading } = useCadastro();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="container flex-1 py-10">
        <div className="mx-auto max-w-6xl">
          <TabelaCadastros 
            cadastros={cadastros} 
            onDelete={deleteCadastro}
            loading={loading}
          />
        </div>
      </main>
    </div>
  );
};

export default ListaCadastros;