import React from "react";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Cadastro } from "@/types";
import { exportToCSV, exportToJSON, exportToXML } from "@/lib/utils";

interface ExportMenuProps {
  data: Cadastro[];
}

export function ExportMenu({ data }: ExportMenuProps) {
  // Função para download de arquivos
  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const a = document.createElement("a");
    const file = new Blob([content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
  };

  // Função para exportar em CSV
  const handleExportCSV = () => {
    const csvContent = exportToCSV(data);
    downloadFile(csvContent, "cadastros-crianças-especiais.csv", "text/csv");
  };

  // Função para exportar em JSON
  const handleExportJSON = () => {
    const jsonContent = exportToJSON(data);
    downloadFile(jsonContent, "cadastros-crianças-especiais.json", "application/json");
  };

  // Função para exportar em XML
  const handleExportXML = () => {
    const xmlContent = exportToXML(data);
    downloadFile(xmlContent, "cadastros-crianças-especiais.xml", "application/xml");
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <Download className="mr-1 h-4 w-4" />
          Exportar
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>Escolha o formato</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleExportCSV}>
          Exportar como CSV
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportJSON}>
          Exportar como JSON
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExportXML}>
          Exportar como XML
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}