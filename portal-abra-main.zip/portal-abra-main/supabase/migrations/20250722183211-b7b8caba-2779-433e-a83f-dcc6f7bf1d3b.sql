-- Create table for cadastros
CREATE TABLE public.cadastros (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  gmus TEXT NOT NULL,
  nome TEXT NOT NULL,
  data_nascimento DATE NOT NULL,
  tipo_deficiencia TEXT NOT NULL,
  profissional TEXT NOT NULL,
  observacao TEXT,
  data_cadastro TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security but with public access policy
ALTER TABLE public.cadastros ENABLE ROW LEVEL SECURITY;

-- Create policy for public access (no authentication required)
CREATE POLICY "Public can read all cadastros" 
ON public.cadastros 
FOR SELECT 
USING (true);

CREATE POLICY "Public can insert cadastros" 
ON public.cadastros 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Public can update cadastros" 
ON public.cadastros 
FOR UPDATE 
USING (true);

CREATE POLICY "Public can delete cadastros" 
ON public.cadastros 
FOR DELETE 
USING (true);