// Tipos de deficiência intelectual
export type TipoDeficiencia = 
  | "AUTISMO" 
  | "SÍNDROME DE DOWN" 
  | "TDAH" 
  | "DISLEXIA" 
  | "DEFICIÊNCIA INTELECTUAL" 
  | "PARALISIA CEREBRAL"
  | "OUTRAS";

// Interface para o cadastro
export interface Cadastro {
  id: string;
  gmus: string;
  nome: string;
  dataNascimento: string;
  tipoDeficiencia: TipoDeficiencia;
  profissional: string;
  observacao: string;
  dataCadastro: string;
}

// Lista de tipos de deficiência para select
export const tiposDeficiencia: TipoDeficiencia[] = [
  "AUTISMO",
  "SÍNDROME DE DOWN",
  "TDAH",
  "DISLEXIA",
  "DEFICIÊNCIA INTELECTUAL",
  "PARALISIA CEREBRAL",
  "OUTRAS"
];